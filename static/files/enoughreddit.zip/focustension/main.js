const loadfunction = window.onload

const youtube = '.ytd-page-manager,.ytd-app'
const reddit = '.thing,.thread'
const fadeOutInterval = Math.floor(Math.random() * 8000) + 1000  

const fadeOutTimeout = () => {
  return Math.floor(Math.random() * 15000) + 3000
}

window.onload = function(event) {
  setTimeout(() => {
    $(reddit).fadeOut(fadeOutInterval)
  }, fadeOutTimeout())

  setInterval(() => {
    if ($(youtube).length !== 0) {
      $(youtube).fadeOut(fadeOutInterval)
    }
  }, fadeOutTimeout)

  if (loadfunction) loadfunction(event)
}